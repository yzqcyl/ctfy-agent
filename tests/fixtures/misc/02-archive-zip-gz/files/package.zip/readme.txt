flag 不在这一层。
